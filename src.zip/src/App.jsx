// App.jsx
import React, { useState } from "react";
import TaskManager from "./components/TaskManager";
import "./App.css";

function App() {
  // Tema light/dark
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <div className={`app ${theme}`}>
      {/* Buton schimbare temă */}
      <div className="theme-toggle-wrapper">
        <button className="theme-toggle-button" onClick={toggleTheme}>
          {theme === "light" ? "Dark mode" : "Light mode"}
        </button>
      </div>

      {/* Managerul de task-uri */}
      <TaskManager />
    </div>
  );
}

export default App;
